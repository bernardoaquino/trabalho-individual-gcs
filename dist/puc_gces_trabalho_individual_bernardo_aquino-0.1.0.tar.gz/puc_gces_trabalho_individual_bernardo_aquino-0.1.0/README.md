# PUC-GCES-PY
Material para o trabalho individual da disciplina de GERÊNCIA DE CONFIGURAÇÃO E EVOLUÇÃO DE SOFTWARE.

## Essa versão é em PYTHON
